#ifndef __TIM_H
#define __TIM_H

void Timer_Init(void);

#endif
