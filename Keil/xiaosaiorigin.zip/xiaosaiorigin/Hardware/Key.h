#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
void Key_Init_A(void);
uint8_t Key_GetNum1(void);
uint8_t Key_GetNum2(void);
uint8_t Key_GetNum3(void);
uint8_t Key_GetNum4(void);
#endif
